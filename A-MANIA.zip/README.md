# A-MANIA: Your Letter Empire Awaits!

Welcome to **A-MANIA**! 🎉
- Type "A" to grow your empire.
- Sign up and log in to save your score.
- Compete on the leaderboard and see who can reach the ultimate A-power!
