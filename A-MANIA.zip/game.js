let users = JSON.parse(localStorage.getItem('users')) || {};
let currentUser = null;

function signup() {
  const user = document.getElementById('username').value;
  const pass = document.getElementById('password').value;
  if (!user || !pass) return alert("Enter username and password!");
  if (users[user]) return alert("Username exists!");
  users[user] = { password: pass, score: 0 };
  localStorage.setItem('users', JSON.stringify(users));
  alert("Sign up successful! Log in now.");
}

function login() {
  const user = document.getElementById('username').value;
  const pass = document.getElementById('password').value;
  if (!users[user] || users[user].password !== pass) {
    document.getElementById('loginMessage').innerText = "Login failed!";
    return;
  }
  currentUser = user;
  document.getElementById('playerName').innerText = user;
  document.getElementById('score').innerText = users[user].score;
  document.getElementById('loginArea').style.display = 'none';
  document.getElementById('gameArea').style.display = 'block';
  updateLeaderboard();
}

function logout() {
  currentUser = null;
  document.getElementById('loginArea').style.display = 'block';
  document.getElementById('gameArea').style.display = 'none';
}

document.addEventListener('keydown', function(e) {
  if (!currentUser) return;
  if (e.key.toLowerCase() === 'a') {
    users[currentUser].score++;
    localStorage.setItem('users', JSON.stringify(users));
    document.getElementById('score').innerText = users[currentUser].score;
    updateLeaderboard();
  }
});

function updateLeaderboard() {
  const leaderboard = Object.entries(users)
    .sort((a,b) => b[1].score - a[1].score)
    .slice(0, 10);
  const list = document.getElementById('leaderboardList');
  list.innerHTML = '';
  leaderboard.forEach(([user, data], i) => {
    const li = document.createElement('li');
    li.innerText = `${i+1}. ${user} - ${data.score} a's`;
    list.appendChild(li);
  });
}
